$(document).ready(function(){
  $('.cal2').clndr({
    template: $("#template-calendar").html()
  });
});
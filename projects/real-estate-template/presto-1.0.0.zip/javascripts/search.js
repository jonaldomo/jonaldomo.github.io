$(document).ready(function(){
    $('select').selectpicker();
});